window.IR_DEFAULTS={shop:{name:'Rolling Wrench Diesel',phone:'260-502-6222',laborRate:135,serviceCall:250,taxRate:0},catalog:[
{part:'Fleetguard LF14000NN',type:'Oil Filter',fits:'Cummins X15 / ISX',cross:'Donaldson P551808, Baldwin BD50000'},
{part:'Fleetguard FS20083',type:'Fuel Water Separator',fits:'Cummins X15 common service',cross:'Baldwin BF46031, Donaldson P551063'},
{part:'Bendix OR275491X',type:'Air Dryer',fits:'AD-9 style',cross:'Haldex 109685X'},
{part:'Meritor A1205S2834',type:'Brake Shoe Kit',fits:'4707 Q Plus 16.5 x 7',cross:'Gunite 3600A'}],labor:[
{job:'Clutch replacement heavy truck with PTO',hours:'10-12'},
{job:'Water pump X15/ISX',hours:'3.5-5.5'},
{job:'Wheel seal axle end',hours:'2.0-3.0'},
{job:'Aftertreatment diagnostics',hours:'1.5-3.0'},
{job:'Roadside no-start / air leak',hours:'2.0 min'}]};
