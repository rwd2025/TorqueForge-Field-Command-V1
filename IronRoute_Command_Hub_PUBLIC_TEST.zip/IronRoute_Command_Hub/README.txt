IronRoute Command Hub
Fresh public-ready test build made from the Rolling Wrench archives.

Upload the CONTENTS of this folder to GitHub Pages, not the zip itself.
Open index.html or your GitHub Pages URL.

This build is designed to not show a blank dashboard. It runs offline with local storage first, then can be connected to Supabase/Render later.

Included modules:
- Dashboard
- Ask AI helper
- Parts master search starter catalog
- Cross references
- Jobs
- Time clock
- Quotes
- Invoices
- Customers
- Trucks/equipment
- Settings
- Backup/export
- PWA manifest and service worker
