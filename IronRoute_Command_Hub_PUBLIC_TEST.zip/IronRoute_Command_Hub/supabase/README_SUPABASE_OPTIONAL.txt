Optional later step:
Add Supabase tables for customers, trucks, jobs, quotes, invoices, photos, chat_memory, parts.
This build does not require Supabase to display and test on GitHub Pages.
