// Optional placeholder for future Supabase Edge Function.
// Connect OCR/photo analysis here later.
Deno.serve(async (req) => new Response(JSON.stringify({ ok:true, message:'Vision endpoint placeholder' }), { headers:{'content-type':'application/json'} }));
