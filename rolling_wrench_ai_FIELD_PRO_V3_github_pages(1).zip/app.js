// Self-contained in index.html
